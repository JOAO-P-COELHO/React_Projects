import React, { useState } from "react";

function App() {
  const [contact, setContact] = useState({
    fName: "",
    lName: "",
    email: ""
  });

  function submitHandler(event){
    const inputValue = event.target.value;
    const inputName = event.target.name;
    console.log(inputName) 
    console.log(inputValue) 

    setContact(prevValue =>{
      if(inputName === "fName"){
        return{ 
          fName: inputValue,
          lName: contact.prevValue,
          email: contact.prevValue
        }}
      else if(inputName === "lName"){
        return {
          fName: contact.prevValue,
          lName: inputValue,
          email: contact.prevValue
        }}
      else{
        return{
          fName: contact.prevValue,
          lName: contact.prevValue,
          email: inputValue
        }
      }
    })

  }

  return (
    <div className="container">
      <h1>
        Hello {contact.fName} {contact.lName}
      </h1>
      <p>{contact.email}</p>
      <form>
        <input name="fName" value={contact.fName} onChange={submitHandler} placeholder="First Name" />
        <input name="lName" value={contact.lName} onChange={submitHandler} placeholder="Last Name" />
        <input name="email" value={contact.email} onChange={submitHandler} placeholder="Email" />
        <button>Submit</button>
      </form>
    </div>
  );
}

export default App;
