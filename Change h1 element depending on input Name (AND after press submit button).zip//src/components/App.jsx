import React,{useState} from "react";

function App() {

const [h1, setH1]= useState("")
const [text, setText] = useState("")

function clickHandler(){
  setH1(", " + text + ".")
}

function nameHandler(){
  console.log(event.target)
  setText(event.target.value)
}

  return (
    <div className="container">
      <h1>Hello{h1} </h1>
      <input type="text" placeholder="What's your name?" value={text} onChange={nameHandler} />
      <button onClick={clickHandler}>Submit</button>
    </div>
  );
}

export default App;
