// Ver lá em baixo o que estava mal no código!!!
// MUITO IMPORTANTE

import React, { useState, useEffect } from 'react';
import './App.css';
import Quote from "./components/Quote";

const array_colors = ["#89CFEF", "#73C2FB", "#95C8D8", "#7285A5", "#BAC1D1", "#BED8C8", "#A9CBB6", "#FFE5D6", "#5ED0E2", "#00BDC1"];

function App() {
  const [key, setKey] = useState(0);
  const [color, setColor] = useState(() => getRandomColor());

  function getRandomColor() {
    const random_num = Math.floor(Math.random() * 10);
    return array_colors[random_num];
  }

  useEffect(() => {
    document.body.style.backgroundColor = color;
  }, [color]);

  const handleNewCitation = () => {
    setKey((currentKey) => currentKey + 1);
    setColor(getRandomColor());
  };

  return (
    <div key={key} id="teste" className="App">
      <br></br>
      <Quote color={color} key={key} />
      <br></br>
      <button id="new_button" onClick={handleNewCitation}>
        New citation
      </button>
    </div>
  );
}

export default App;





























// import { useState, useEffect } from 'react';
// import './App.css';
// import Quote from "./components/Quote";


// const array_colors=["#89CFEF","#73C2FB","#95C8D8","#7285A5","#BAC1D1","#BED8C8","#A9CBB6","#FFE5D6","#5ED0E2","#00BDC1"]
// let random_num = Math.floor(Math.random() * 10);
// const random_color = array_colors[random_num]   
// console.log(random_color)

// function App() {
  
//   const [key, setKey] = useState(0)
  
//   console.log(key)
//   const [color, setColor] = useState(() => getRandomColor());
//   console.log(color)  

//   useEffect(() => {
//     setColor(random_color)    
//     document.body.style.backgroundColor = random_color   
//     console.log(color)   
//   }, [color]);

//   function getRandomColor() {
//     const random_num = Math.floor(Math.random() * 10);
//     return array_colors[random_num];
//   }

//   const handleNewCitation = () => {
//     setKey((currentKey) => currentKey + 1);
//     setColor(getRandomColor());
//   };
  
//   return (
//     <div key={key} id="teste" className="App">
//     {console.log(key)}
//     {console.log(color)}
//       <br></br>
//       < Quote color ={color} key ={key} />
//       <br></br>
//       <button id="new_button" onClick={handleNewCitation}>New citation</button>
//     </div> 
//   );
// }


// export default App;

