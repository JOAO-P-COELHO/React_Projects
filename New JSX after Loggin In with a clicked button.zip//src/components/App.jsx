import React, { useState } from "react";

function App() {
  const [button, setButton] = useState(true);

  function clicked() {
    setButton(false);
  }

  return (
    <div className="container">
      {button ? (
        <div>
          <h1>Hello. </h1>
          <p>Please Login</p>
          <button type="button" onClick={clicked}>
            Login
          </button>
        </div>
      ) : (
        <h1>Logged In.</h1>
      )}
    </div>
  );
}

export default App;
