import React from "react";

function Form(props) {
  return (
    <form className="form">
      <input  type="text" placeholder="Username" />
      <input type="password" placeholder="Password" />
      {props.LogedIn === false && <input type="password" placeholder="Confirm Password" /> }
      {/* EQUALS TO: {!props.LogedIn && <input type="password" placeholder="Confirm Password" /> } */}
      <button type="submit">{props.LogedIn? "Login" : "Register"}</button>
    </form>
  );
}

export default Form;
