import React from "react";
import ReactDOM from "react-dom/client";
import App from "./App";

const root = ReactDOM.createRoot(document.getElementById("root"));
root.render(<App />);

// READ ME:

// I removed the </React.StrictMode> because this was making my app render twice in a row
// React.StrictMode renders the application twice in the development mode to check
// the side effects and the bad code and practices.

// By removing it I made my app render only once, and the "error" disappeared

//  Project dificulty (out of 5): 4
//  Time spent: ~14,3 hours
