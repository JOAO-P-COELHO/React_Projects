import React, { useState, useEffect } from "react";
import "./App.css";
import Quote from "./components/Quote";
import Footer from "./components/Footer";

const array_colors = [
  "#d1d1d1",
  "#a0ced9",
  "#95b8d1",
  "#b8e0d2",
  "#9cadce",
  "#7ec4cf",
  "#79addc",
  "#b5d6d6",
  "#b3dee2",
  "#bde0fe",
  "#a7bed3",
]; //Array of 11 colors

function App() {
  const [key, setKey] = useState(0); // a useState to change the div key - by changing the key, the component it's forced to re-render - this is activateb by pressing the button
  const [color, setColor] = useState(() => getRandomColor()); // this useState calls a function that generates a random calor to the initial value of color

  function getRandomColor() {
    const random_num = Math.floor(Math.random() * 11); // pick a random number from 1-11
    return array_colors[random_num]; // using that random number pick a color from the array
  }

  useEffect(() => {
    // the useEffect it's a function that accepts two arguments: a function and an array of dependencies(things that will depend on this hook). useEffect(() => { function }, [array]);
    // The function inside the useEffect it's executed after the initial rendering and after an update in any of the dependendencies in the array.
    document.body.style.backgroundColor = color; // In this case, after the rendering, the color of the body of the document it's changed to the color set in setColor
  }, [color]);

  const handleNewCitation = () => {
    //Calling this function, change the state of key and color (the second one, the color, forces the re-render of the page because of the useEffect)
    setKey((currentKey) => currentKey + 1); // By updating the key, the <Quote /> component will get a new key, what will make it to re-render
    setColor(getRandomColor()); // By calling the setColor and setting a new color, I force the whole page to re-render.
    // This happens because the useEffect ('s effect), that has as a dependency (precisely) the variable color, that, when changed,
    // forces the whole page to re-render as "colateral"/as an effect.
  };

  return (
    <div id="teste" className="App">
      <br></br>
      <Quote color={color} key={key} />{" "}
      {/* The color is is passed to the <Quote /> component, which will then make those specific elements have this same color */}
      <br></br>
      <button id="new_button" onClick={handleNewCitation}>
        {" "}
        {/* the button "new_button", triggers the change in key (by calling the setKey) and color (by calling the setColor) */}
        <span style={{ color: "black" }}>New</span> citation
      </button>
      <Footer />
    </div>
  );
}

export default App;
