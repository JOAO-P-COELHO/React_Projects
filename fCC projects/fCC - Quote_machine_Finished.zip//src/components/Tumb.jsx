import React from "react";

const Tumb = (props) => {
  const author = props.author; // Get the author's name
  const encoded_author = encodeURIComponent(author); // Convert it to URL code

  const quote = props.quote; // Get the author's quote
  const encoded_quote = encodeURIComponent(quote); // Convert it to URL code

  const text_1 =
    "https://www.tumblr.com/widgets/share/tool?posttype=quote&tags=quotes=";
  const text_2 = "&content=";
  const text_3 =
    "&canonicalUrl=https%3A%2F%2Fjoao-p-coelho.github.io/myPortefolio/"; // Substituing exactly "joao-p-coelho.github.io/myPortefolio/" makes tumblr share the link/website that I want
  const final_text = text_1 + encoded_author + text_2 + encoded_quote + text_3;
  console.log(final_text);

  return (
    <div>
      <a id="tumb" href={final_text} data-size="large" target="_blank">
        <svg
          xmlns="http://www.w3.org/2000/svg"
          height="3em"
          width="3em"
          viewBox="0 0 320 512"
        >
          <path d="M309.8 480.3c-13.6 14.5-50 31.7-97.4 31.7-120.8 0-147-88.8-147-140.6v-144H17.9c-5.5 0-10-4.5-10-10v-68c0-7.2 4.5-13.6 11.3-16 62-21.8 81.5-76 84.3-117.1 .8-11 6.5-16.3 16.1-16.3h70.9c5.5 0 10 4.5 10 10v115.2h83c5.5 0 10 4.4 10 9.9v81.7c0 5.5-4.5 10-10 10h-83.4V360c0 34.2 23.7 53.6 68 35.8 4.8-1.9 9-3.2 12.7-2.2 3.5 .9 5.8 3.4 7.4 7.9l22 64.3c1.8 5 3.3 10.6-.4 14.5z" />
        </svg>
      </a>
      <p>Tumblr it.</p>
    </div>
  );
};

export default Tumb;
