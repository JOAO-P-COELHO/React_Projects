import React from "react";

const d = new Date();
let day = d.getFullYear();

function Footer() {
  return (
    <div>
      <br></br>
      <p> - made by JC - </p>
      <p> {day}</p>
      <br></br>
    </div>
  );
}

export default Footer;
