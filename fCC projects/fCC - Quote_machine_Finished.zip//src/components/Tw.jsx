import React from "react";

const Tw = (props) => {
  const author = props.author; // Get the author's name
  const encoded_author = encodeURIComponent(author); // Convert it to URL code

  const quote = props.quote; // Get the author's quote
  const encoded_quote = encodeURIComponent(quote); // Convert it to URL code
  const new_line = "%0D%0A%0D%0A"; //Added this URL code to make it add 2 new lines (each line = "%0D%0A")

  const text_1 = "https://twitter.com/intent/tweet?text=";
  const final_text = text_1 + encoded_quote + new_line + "- " + encoded_author;

  return (
    <div>
      <a id="twitter" href={final_text} data-size="large" target="_blank">
        <svg
          id="twitter"
          xmlns="http://www.w3.org/2000/svg"
          height="3em"
          width="3em"
          data-fa-transform="rotate-90"
          viewBox="0 0 512 512"
        >
          <path d="M459.4 151.7c.3 4.5 .3 9.1 .3 13.6 0 138.7-105.6 298.6-298.6 298.6-59.5 0-114.7-17.2-161.1-47.1 8.4 1 16.6 1.3 25.3 1.3 49.1 0 94.2-16.6 130.3-44.8-46.1-1-84.8-31.2-98.1-72.8 6.5 1 13 1.6 19.8 1.6 9.4 0 18.8-1.3 27.6-3.6-48.1-9.7-84.1-52-84.1-103v-1.3c14 7.8 30.2 12.7 47.4 13.3-28.3-18.8-46.8-51-46.8-87.4 0-19.5 5.2-37.4 14.3-53 51.7 63.7 129.3 105.3 216.4 109.8-1.6-7.8-2.6-15.9-2.6-24 0-57.8 46.8-104.9 104.9-104.9 30.2 0 57.5 12.7 76.7 33.1 23.7-4.5 46.5-13.3 66.6-25.3-7.8 24.4-24.4 44.8-46.1 57.8 21.1-2.3 41.6-8.1 60.4-16.2-14.3 20.8-32.2 39.3-52.6 54.3z" />
        </svg>
      </a>
      <p>Tweet it.</p>
    </div>
  );
};

export default Tw;
