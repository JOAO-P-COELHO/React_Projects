import React, { useState, useEffect } from "react";
import Tw from "./Tw";
import Tumb from "./Tumb";

const apiKey = "O9LxQFisqMTi0U0JGZtU6Q==8AxMLTd2rMXVhcvq";
const apiUrl = "https://api.api-ninjas.com/v1/quotes?category=inspirational";

function Quote(props) {
  const [quotes, setQuotes] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  console.log(props.color);

  useEffect(() => {
    fetch(apiUrl, {
      // Makes the request to that URL, in this case "apiUrl"
      headers: { "X-Api-Key": apiKey },
    })
      .then((response) => response.json()) // Converts that response to the JSON format
      .then((data) => {
        setQuotes(data); // It updates quotes, by the setQuotes(using the data obtained)
        setIsLoading(false); // It changes the state of isLoading to false when it gets the data
      })
      .catch((error) => console.error("Error:", error)); // If and error occurs, it consoles it
  }, []);

  return (
    <div id="white_division">
      {isLoading ? (
        <p>
          <span
            style={{ color: props.color }}
            id="waiting_icon"
            class="material-symbols-outlined"
          >
            {" "}
            all_inclusive{" "}
          </span>
        </p> // Here, a fragment ("<>...</>") (could have been a div) it's needed because you can't use more than one element inside of the ternary operator - by grouping them (the h1 and p), you can now render the all piece
      ) : (
        <>
          <h1 style={{ color: props.color }} id="h1">
            <span
              style={{ color: props.color }}
              id="waiting_icon"
              class="material-symbols-outlined"
            >
              {" "}
              all_inclusive{" "}
            </span>
            {quotes[0].quote}
          </h1>
          <hr id="hr"></hr>
          <p style={{ color: props.color }} id="p">
            {quotes[0].author}
          </p>

          <div id="icons_div">
            <Tw quote={quotes[0].quote} author={quotes[0].author} />
            <Tumb quote={quotes[0].quote} author={quotes[0].author} />
          </div>
        </>
      )}
    </div>
  );
}

export default Quote;
