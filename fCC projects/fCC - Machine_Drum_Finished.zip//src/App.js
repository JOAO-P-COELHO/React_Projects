import React, { useState } from "react";
import Topbar from "./components/Topbar";
import Music_A from "./components/Music_A";
import Music_B from "./components/Music_B";
import Button_off from "./components/Button_off";
import Button_on from "./components/Button_on";
import Footer from "./components/Footer";
import { Howl } from "howler";

function App() {
  // Defining how bank is changed and (visual) consequences of that:
  var [valueBank, setValueBank] = useState("A"); // By default, the selected bank it's "A"

  function def_BankA() {
    // This is what happens when, by clicking the button "A", the def_BankA function is called:
    if (valueBank == "B" && valorVol == "") {
      // If valueBank it's "B" (wich means that, currently, the machine is using the bank "B") and valorVol=="" (wich means, the machine is On)
      playSound(Sound2); // This sound plays when banks changed, this calls the playSound function, that uses as argument Sound2
      setValueBank("A"); // This sets the machine back valueBank =="A"
      document.getElementById("bank_A").style.backgroundColor = "lightblue"; // Also A gets lightblue background
      document.getElementById("bank_B").style.backgroundColor = "#D0D0D0"; // And B gets the default background
    } else if (valueBank == "B" && valorVol == "disabled") {
      // If the machine it's not On (i.e., valorVol =="disabled") then, no bank it's selected, and no button gets a lightblue color
      document.getElementById("bank_A").style.backgroundColor = "#D0D0D0";
      document.getElementById("bank_B").style.backgroundColor = "#D0D0D0";
    }
  }

  function def_BankB() {
    // Same logic used before, but, this time, it's used when button "B" it's clicked
    if (valueBank == "A" && valorVol == "") {
      playSound(Sound2);
      setValueBank("B");
      document.getElementById("bank_B").style.backgroundColor = "lightblue";
      document.getElementById("bank_A").style.backgroundColor = "#D0D0D0";
    } else if (valueBank == "A" && valorVol == "disabled") {
      document.getElementById("bank_A").style.backgroundColor = "#D0D0D0";
      document.getElementById("bank_B").style.backgroundColor = "#D0D0D0";
    }
  }

  var Sound2 = new Howl({
    src: [
      "https://www.orangefreesounds.com/wp-content/uploads/2019/03/Button-click-sound-effect.mp3?_=1",
    ],
    volume: 0.8,
  }); // Sound used when one of the bank's buttons is clicked - the volume is always 0.8, i.e., 80%

  function playSound(sound) {
    // PlaySound function is part of Howl, and uses an argument, in this case, it's always Sound2
    sound.play(); // This is how How plays sounds, it calls the play function.
  }

  // Defining how On/Off buttons turn On or turn Off the machine:
  const [powerbutton, setpowerButton] = useState(true); // By default, the button power it's always On
  const [valorVol, setValorVol] = useState(""); // By default, the machine is always operacional (when this parameter it's set as "disabled", the machine doesn't play sounds at all, not by clicking, nor by pressing keys on keyboard)
  const [on, setOn] = useState("On"); // By default, the machine always display "On"

  function powerbuttonClick() {
    // This function is called when the div/button is clicked
    setpowerButton(!powerbutton); // So, when the button is clicked, it sets the the powerbutton to is opposite

    if (valorVol == "") {
      // If the machine is operational ' "" ' (it's not "disabled") then
      setValorVol("disabled"); // Make its state to "disabled"
      setOn("Off"); // Make appear "Off", instead of "On"
      document.getElementById("bank_A").style.backgroundColor = "#D0D0D0"; // Buttons get default color (it makes it appear as if none is selected)
      document.getElementById("bank_B").style.backgroundColor = "#D0D0D0"; // Buttons get default color (it makes it appear as if none is selected)
    } else {
      setValorVol(""); // Same logic, but, this time, the machine is set as "disabled", if so:
      setOn("On");
      document.getElementById("bank_A").style.backgroundColor = "lightblue"; // Make machine turn On and "appears" that bank A it's set by default
      document.getElementById("bank_B").style.backgroundColor = "#D0D0D0";
    }
  }

  return (
    <div>
      <Topbar />
      <fieldset className="fields">
        <legend className="fields">{on}</legend>{" "}
        {/* On/Off message - it depens on setOn */}
        <div>
          <div onClick={powerbuttonClick}>
            {powerbutton ? <Button_on /> : <Button_off />}{" "}
            {/* If powerbutton = true, then, the machine is on, then show the On button, otherwise, show the Off button*/}
          </div>
        </div>
      </fieldset>
      <div className="fields">
        {valueBank == "A" ? (
          <Music_A volume={valorVol} />
        ) : (
          <Music_B volume={valorVol} />
        )}{" "}
        {/* If valueBank =="A" then, call the component Music_A, otherwise, call the Music_B component, that corresponds to another bank of sounds */}
      </div>
      <fieldset id="bank_choice" className="fields">
        <legend id="bank_selector">Select a bank of samples:</legend>
        <div>
          <button id="bank_A" className="bank_button" onClick={def_BankA}>
            A
          </button>{" "}
          {/* If button A it's clicked, call the function def_BankA */}
          <button id="bank_B" className="bank_button" onClick={def_BankB}>
            B
          </button>{" "}
          {/* If button B it's clicked, call the function def_BankB */}
        </div>
      </fieldset>
      <Footer />
    </div>
  );
}

export default App;
