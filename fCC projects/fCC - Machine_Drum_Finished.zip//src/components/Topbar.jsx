import React from "react";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome"; // This library it's used for the drummer icon on the Topbar
import { faDrum } from "@fortawesome/free-solid-svg-icons"; // This library it's used for the drummer icon on the Topbar

const Topbar = () => {
  return (
    <nav className="navbar">
      <h1>
        <span className="my">my</span>Drum Machine.
      </h1>
      <FontAwesomeIcon className="tambor" icon={faDrum} />{" "}
      {/* This is how FontAwesome Icon recomends setting icons in React - better use <svg> */}
    </nav>
  );
};

export default Topbar;
