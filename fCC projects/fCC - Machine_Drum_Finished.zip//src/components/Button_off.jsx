// This component composes and defines what happens when Off button it's pressed (a sound)

import React from "react";
import { Howl } from "howler"; // Sound library

function Button_off() {
  var Sound1 = new Howl({
    src: [
      "https://orangefreesounds.com/wp-content/uploads/2023/01/Play-button-sound-effect.mp3?_=1",
    ],
    volume: 0.8,
  });
  function playSound(sound) {
    sound.play();
  }

  return (
    <svg
      onClick={() => playSound(Sound1)}
      className="off_on_buttons"
      xmlns="http://www.w3.org/2000/svg"
      height="16"
      width="18"
      viewBox="0 0 576 512"
    >
      <path d="M384 64H192C86 64 0 150 0 256s86 192 192 192h192c106 0 192-86 192-192S490 64 384 64zM64 256c0-70.7 57.2-128 128-128 70.7 0 128 57.2 128 128 0 70.7-57.2 128-128 128-70.7 0-128-57.2-128-128zm320 128h-48.9c65.2-72.9 65.2-183.1 0-256H384c70.7 0 128 57.2 128 128 0 70.7-57.2 128-128 128z" />
    </svg>
  );
}

export default Button_off;
