// This component it's composed of the sounds to play when bank A is On

import React, { useState, useEffect } from "react";
import { Howl } from "howler"; // Sound library

function Music_A(props) {
  console.log(props.volume); // If Off button it's set, then, props.volume === disabled, if On button it's set, then, props.volume = [empty string]
  let control_volume = props.volume;
  const [valor, setValor] = useState(50); //This hook going to set the value of the volume. By default it's on 50(%)
  const [keyPressed, setKeyPressed] = useState(false); // This hook by default sets keypressed as "false". When a key it's pressed setKeyPressed it's updated

  const handleSliderChange = (event) => {
    // This function is called when the input/slider is changed (by onChange). It sets the value of "valor" to the value catch on event.target.value
    setValor(event.target.value);
  };

  function playSound(sound) {
    // This function it's called by click events or keyboard events.
    if (control_volume == "") {
      // If props.volume == [empty string] (something that happens when On button is on ) then sounds can be played
      sound.play(); //It calls "play", function by Howl
    }
  }

  // These is the library of sounds used. These object are set with a volume that depends on the "valor" value, set earlier wit the hook - by default the volume it's on 50%. They have to be divided by 100, because in this library 100 % = 1.0
  var Sound1 = new Howl({
    src: ["https://s3.amazonaws.com/freecodecamp/drums/Heater-1.mp3"],
    volume: valor / 100,
  });
  var Sound2 = new Howl({
    src: ["https://s3.amazonaws.com/freecodecamp/drums/Heater-2.mp3"],
    volume: valor / 100,
  });
  var Sound3 = new Howl({
    src: ["https://s3.amazonaws.com/freecodecamp/drums/Heater-3.mp3"],
    volume: valor / 100,
  });
  var Sound4 = new Howl({
    src: ["https://s3.amazonaws.com/freecodecamp/drums/Heater-4_1.mp3"],
    volume: valor / 100,
  });
  var Sound5 = new Howl({
    src: ["https://s3.amazonaws.com/freecodecamp/drums/Heater-6.mp3"],
    volume: valor / 100,
  });
  var Sound6 = new Howl({
    src: ["https://s3.amazonaws.com/freecodecamp/drums/Dsc_Oh.mp3"],
    volume: valor / 100,
  });
  var Sound7 = new Howl({
    src: ["https://s3.amazonaws.com/freecodecamp/drums/Kick_n_Hat.mp3"],
    volume: valor / 100,
  });
  var Sound8 = new Howl({
    src: ["https://s3.amazonaws.com/freecodecamp/drums/RP4_KICK_1.mp3"],
    volume: valor / 100,
  });
  var Sound9 = new Howl({
    src: ["https://s3.amazonaws.com/freecodecamp/drums/Cev_H2.mp3"],
    volume: valor / 100,
  });

  const keyDownHandler = (event) => {
    // This function is called when a key is pressed (it's catch by window.addEventListener, that, then, calls this function using the properties of the event)
    let pressedKey = event.key.toLowerCase(); // This make sure that even if Caps Lock is on, the key still triggers a sound
    if (pressedKey === "q") {
      // If the key pressed (pressedKey) == "q", then, it plays the Sound1 (sound specific for this key). Also if this is true, setKeyPressed is called, and the value of keyPressed it's updated
      playSound(Sound1);
      setKeyPressed("q");
    } else if (pressedKey === "w") {
      playSound(Sound2);
      setKeyPressed("w");
    } else if (pressedKey === "e") {
      playSound(Sound3);
      setKeyPressed("e");
    } else if (pressedKey === "a") {
      playSound(Sound4);
      setKeyPressed("a");
    } else if (pressedKey === "s") {
      playSound(Sound5);
      setKeyPressed("s");
    } else if (pressedKey === "d") {
      playSound(Sound6);
      setKeyPressed("d");
    } else if (pressedKey === "z") {
      playSound(Sound7);
      setKeyPressed("z");
    } else if (pressedKey === "x") {
      playSound(Sound8);
      setKeyPressed("x");
    } else if (pressedKey === "c") {
      playSound(Sound9);
      setKeyPressed("c");
    }
  };

  const keyUpHandler = () => {
    //This function is called when a key is released (it's catch by window.addEventListener, that, then, calls this function). It makes the keyPressed set to null
    setKeyPressed(null);
  };

  useEffect(() => {
    // This hook is called on the first render and any time any dependency value changes (in this case, props.volume and valor - the first sets if the machine is on or off, and the second the volume of the sounds)
    // This event listener works as:  window.addEventListener(event, function, Capture).  Note that, in this case, can be window.addEventListener or document.addEventListener, they both listen something happening in the page. An event can be a key, a click, etc.
    window.addEventListener("keydown", keyDownHandler); // The keydown event is fired when a key is pressed and calls the keyDownHandler function
    window.addEventListener("keyup", keyUpHandler); // The keyup event is fired when a key is released and calls the keyUpHandler function

    if (props.volume === "disabled") {
      // If props.volume (set by the On/Off buttons) is == "disabled", then the volume of all the sounds it's set to 0
      Sound1.volume(0); //(method) Howl.volume - this is how Howl defines volume directly
      Sound2.volume(0);
      Sound3.volume(0);
      Sound4.volume(0);
      Sound5.volume(0);
      Sound6.volume(0);
      Sound7.volume(0);
      Sound8.volume(0);
      Sound9.volume(0);
    } else {
      // If props.volume it's not == "disabled", then the volume of all the sounds it's set to 100. "valor" is defined by the handleSliderChange
      Sound1.volume(valor / 100);
      Sound2.volume(valor / 100);
      Sound3.volume(valor / 100);
      Sound4.volume(valor / 100);
      Sound5.volume(valor / 100);
      Sound6.volume(valor / 100);
      Sound7.volume(valor / 100);
      Sound8.volume(valor / 100);
      Sound9.volume(valor / 100);
    }

    return () => {
      // Some effects require cleanup to reduce memory leaks. Timeouts, subscriptions, event listeners, and other effects that are no longer needed should be disposed. We do this by including a return function at the end of the useEffect Hook.
      window.removeEventListener("keydown", keyDownHandler); //At the end of a re-rendering (caused, per example, by pressing a key, that, calls a function that calls setKeyPressed('q') and sets a new value for the state "keyPressed"), the event listeners are removed
      window.removeEventListener("keyup", keyUpHandler);
    };
  }, [props.volume, valor]); // This hook is called (on the first render and) any time any dependency value changes (in this case, props.volume and valor - the first sets if the machine is on or off, and the second the volume of the sounds)

  return (
    <div className="buttons">
      <br></br>
      <br></br>
      <input
        type="range"
        className="volume_button"
        id="volume"
        min="0"
        max="100"
        step="1"
        value={valor}
        onChange={handleSliderChange}
      />{" "}
      {/* onChange calls the function handleSliderChange, that updates the value of valor, and by that, the volume of the sounds and the number disposed on screen, next to "Volume" | Also, notice, that the atribute "value" of this input, in React, it has to be defined always, or it can cause problems */}
      <p id="p_volume"> Volume: {valor}</p>
      {/* When keyPressed ==="that key" [this only happens when "that key" is pressed, because SetKeyPressed sets it - even though, it's removed after the key is no longer pressed, by the keyUpHandler, setting keyPressed ==null] and the machine is not disabled, then the buttons have a lightblue color, if not, they have the default color. Also, buttons are disabled if the props.volume (that is [empty string] or "disabled]) it's equal to disabled. Finally, when a button it's clicked it automatically plays a sound, calling the function created by Howl, "playSound". This function takes an argument, that it is Sound1, Sound2, etc, depending on the button clicked. */}
      <button
        id="q"
        style={{
          backgroundColor:
            keyPressed === "q" && props.volume != "disabled"
              ? "lightblue"
              : "#D0D0D0",
        }}
        disabled={props.volume}
        onClick={() => playSound(Sound1)}
      >
        Q
      </button>
      <button
        id="w"
        style={{
          backgroundColor:
            keyPressed === "w" && props.volume != "disabled"
              ? "lightblue"
              : "#D0D0D0",
        }}
        disabled={props.volume}
        onClick={() => playSound(Sound2)}
      >
        W
      </button>
      <button
        id="s"
        style={{
          backgroundColor:
            keyPressed === "e" && props.volume != "disabled"
              ? "lightblue"
              : "#D0D0D0",
        }}
        disabled={props.volume}
        onClick={() => playSound(Sound3)}
      >
        E
      </button>
      <button
        id="e"
        style={{
          backgroundColor:
            keyPressed === "a" && props.volume != "disabled"
              ? "lightblue"
              : "#D0D0D0",
        }}
        disabled={props.volume}
        onClick={() => playSound(Sound4)}
      >
        A
      </button>
      <button
        id="d"
        style={{
          backgroundColor:
            keyPressed === "s" && props.volume != "disabled"
              ? "lightblue"
              : "#D0D0D0",
        }}
        disabled={props.volume}
        onClick={() => playSound(Sound5)}
      >
        S
      </button>
      <button
        id="z"
        style={{
          backgroundColor:
            keyPressed === "d" && props.volume != "disabled"
              ? "lightblue"
              : "#D0D0D0",
        }}
        disabled={props.volume}
        onClick={() => playSound(Sound6)}
      >
        D
      </button>
      <button
        id="a"
        style={{
          backgroundColor:
            keyPressed === "z" && props.volume != "disabled"
              ? "lightblue"
              : "#D0D0D0",
        }}
        disabled={props.volume}
        onClick={() => playSound(Sound7)}
      >
        Z
      </button>
      <button
        id="x"
        style={{
          backgroundColor:
            keyPressed === "x" && props.volume != "disabled"
              ? "lightblue"
              : "#D0D0D0",
        }}
        disabled={props.volume}
        onClick={() => playSound(Sound8)}
      >
        X
      </button>
      <button
        id="c"
        style={{
          backgroundColor:
            keyPressed === "c" && props.volume != "disabled"
              ? "lightblue"
              : "#D0D0D0",
        }}
        disabled={props.volume}
        onClick={() => playSound(Sound9)}
      >
        C
      </button>
    </div>
  );
}

export default Music_A;
