// This component composes the footer - it shows the current year automatically

import React from "react";

const d = new Date();
let year = d.getFullYear();

function Footer() {
  return (
    <div id="footer">
      <br></br>
      <p> - made by JC - </p>
      <p>{year}</p>
      <br></br>
    </div>
  );
}

export default Footer;
