// This component composes and defines what happens when Off button it's pressed (a sound)

import React from "react";
import { Howl } from "howler"; // Sound library

function Button_on() {
  var Sound1 = new Howl({
    src: [
      "https://www.orangefreesounds.com/wp-content/uploads/2022/03/Tv-turn-off-sound-effect.mp3?_=1",
    ],
    volume: 0.8,
  });
  function playSound(sound) {
    sound.play();
  }

  return (
    <svg
      onClick={() => playSound(Sound1)}
      className="off_on_buttons"
      xmlns="http://www.w3.org/2000/svg"
      height="16"
      width="18"
      viewBox="0 0 576 512"
    >
      <path d="M192 64C86 64 0 150 0 256S86 448 192 448H384c106 0 192-86 192-192s-86-192-192-192H192zm192 96a96 96 0 1 1 0 192 96 96 0 1 1 0-192z" />
    </svg>
  );
}

export default Button_on;
