import React, { useState } from "react";
import Preview from "./Preview";

export default function Editor() {
  // This variable has the text that appear as an example on the textarea
  let def_value =
    "# This is my React Markdown Previewer!🙂 \n\n## Per example, this is a sub-heading... \n### And here's some other cool stuff (a h3 element): \n\nHere's some code, `<div></div>`, between 2 backticks.\n\n```\n// this is a multi-line code:\n\nfunction anotherExample(firstLine, lastLine) {\n  if (firstLine == '```' && lastLine == '```') {\n    return multiLineCode;\n  }\n}\n```\n\nWith this converter app, you can also make the text **bold**...!😉 \n\nOr _italic_. \n\nOr... **_both!_**\nAnd feel free to go crazy ~~crossing stuff out~~.\n\nThere's also [links](https://github.com/JOAO-P-COELHO), and\n> Block Quotes!\n\nAnd if you want to get really crazy, even tables:\n\nHeader | Other Header | Another Header?\n------------ | ------------- | -------------\nYour content can | be here, and it | can be here....\nAnd here. | Okay. | I think we get it.😅\n\n- And of course there are lists.\n  - Some are bulleted.\n     - With different indentation levels.\n        - That look like this.\n\n\n1. And there are numbered lists too.\n1. You can use just one, if you want to!\n1. And last but not least, let's not forget embedded images, like this React logo:\n\n![React Logo](https://www.svgrepo.com/show/314526/react.svg)";

  const [text, setText] = useState(def_value); // Initially the text appearing it's the one in the def_value variable
  function getText(event) {
    // This function it's called on the onChange event on the textarea element. When the text in this element it's changed, this function it's activated and it's new value it's get and set by the setText hook.
    setText(event.target.value);
  }

  const [windows_size, setWindows_Size] = useState("normal"); // This is a variable used to control the size of the windows.
  const [area_size, setArea_Size] = useState(15); // This is the variable that defines the height ot that windows

  function windowsHandler() {
    // This function it's called when the windows icon it's clicked.

    if (windows_size === "normal") {
      // If the size its set to normal then do:
      setWindows_Size("large"); // Changes the "state" of this element
      setArea_Size(25); // This enlarges the number of rows shown
      const element = document.getElementById("previewer"); // This gets the previewer element by id and hides it
      if (element.style.display === "none") {
        element.style.display = "block";
      } else {
        element.style.display = "none";
      }
    } else if (windows_size === "large") {
      // If the size its set to large then do:
      setWindows_Size("normal"); // Changes the "state" of this element to default
      setArea_Size(15); // This set the number of rows shown to the default value
      const element = document.getElementById("previewer"); // This gets the previewer element and re-opens it
      if (element.style.display === "none") {
        element.style.display = "block";
      } else {
        element.style.display = "none";
      }
    }
  }

  return (
    <div>
      <div class="container" id="editori">
        <div className="header_1">
          <div>
            {windows_size === "normal" ? ( // If the "state" of the element it's set to normal, it shows an icon (the icon that shows that this element can be open), if its set to "large", the icon changes
              <svg
                className="windows"
                onClick={windowsHandler}
                xmlns="http://www.w3.org/2000/svg"
                height="20"
                width="20"
                viewBox="0 0 512 512"
              >
                <path d="M464 32H48C21.5 32 0 53.5 0 80v352c0 26.5 21.5 48 48 48h416c26.5 0 48-21.5 48-48V80c0-26.5-21.5-48-48-48zm0 394c0 3.3-2.7 6-6 6H54c-3.3 0-6-2.7-6-6V192h416v234z" />
              </svg>
            ) : (
              <svg
                className="windows"
                onClick={windowsHandler}
                xmlns="http://www.w3.org/2000/svg"
                height="20"
                width="20"
                viewBox="0 0 512 512"
              >
                <path d="M464 352H48c-26.5 0-48 21.5-48 48v32c0 26.5 21.5 48 48 48h416c26.5 0 48-21.5 48-48v-32c0-26.5-21.5-48-48-48z" />
              </svg>
            )}
          </div>
          <div className="align_center">
            <svg
              className="symbol"
              xmlns="http://www.w3.org/2000/svg"
              height="25"
              width="25"
              viewBox="0 0 640 512"
            >
              <path d="M392.8 1.2c-17-4.9-34.7 5-39.6 22l-128 448c-4.9 17 5 34.7 22 39.6s34.7-5 39.6-22l128-448c4.9-17-5-34.7-22-39.6zm80.6 120.1c-12.5 12.5-12.5 32.8 0 45.3L562.7 256l-89.4 89.4c-12.5 12.5-12.5 32.8 0 45.3s32.8 12.5 45.3 0l112-112c12.5-12.5 12.5-32.8 0-45.3l-112-112c-12.5-12.5-32.8-12.5-45.3 0zm-306.7 0c-12.5-12.5-32.8-12.5-45.3 0l-112 112c-12.5 12.5-12.5 32.8 0 45.3l112 112c12.5 12.5 32.8 12.5 45.3 0s12.5-32.8 0-45.3L77.3 256l89.4-89.4c12.5-12.5 12.5-32.8 0-45.3z" />
            </svg>
            <i className="toolbar_i"> Write your marked code here: </i>
          </div>
        </div>
        <div>
          <textarea
            defaultValue={def_value}
            onChange={getText}
            name="editor"
            id="editor"
            cols="70"
            rows={area_size}
          ></textarea>
        </div>
      </div>
      <Preview text_pass={text} />
    </div>
  );
}
