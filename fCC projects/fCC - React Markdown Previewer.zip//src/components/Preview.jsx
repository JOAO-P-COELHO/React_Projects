import React, { useEffect, useState } from "react";
import ReactMarkdown from "react-markdown"; // This is the library that converts the markdown text to html
import remarkGfm from "remark-gfm"; // These are plugins that that library needs
// import rehypeKatex from "https://esm.sh/rehype-katex@7"; // These are plugins that that library needs - doesn't work properly on sandbox

export default function Preview(props) {
  const [windows_size, setWindows_Size] = useState("normal"); // This is a variable used to control the size of the windows.
  const [preview_value, setPreview_value] = useState(props.text_pass); // The props variable is going to define what it's shown in the React Markdown Component
  function windowsHandler() {
    // This function it's called when the windows icon it's clicked.

    if (windows_size === "normal") {
      // If the size its set to normal then do:
      setWindows_Size("large"); // Changes the "state" of this element
      const element = document.getElementById("editori"); // This gets the editor element by id and hides it
      if (element.style.display === "none") {
        element.style.display = "block";
      } else {
        element.style.display = "none";
      }
    } else if (windows_size === "large") {
      // If the size its set to large then do:
      setWindows_Size("normal"); // Changes the "state" of this element to default
      const element = document.getElementById("editori"); // This gets the editor element and re-opens it
      if (element.style.display === "none") {
        element.style.display = "block";
      } else {
        element.style.display = "none";
      }
    }
  }

  useEffect(() => {
    // Every time the props used it's updated, the component it's re-rendered
    setPreview_value(props.text_pass);
  }, [props.text_pass]); // This is the dependency and it is, precisely, the props used, so, everytime it changes, it "activates" the useEffect, what provokes the component re-rendering

  return (
    <div id="previewer">
      <div class="container">
        <div className="header_2">
          <div>
            {windows_size === "normal" ? ( // If the "state" of the element it's set to normal, it shows an icon (the icon that shows that this element can be open), if its set to "large", the icon changes
              <svg
                className="windows"
                onClick={windowsHandler}
                xmlns="http://www.w3.org/2000/svg"
                height="20"
                width="20"
                viewBox="0 0 512 512"
              >
                <path d="M464 32H48C21.5 32 0 53.5 0 80v352c0 26.5 21.5 48 48 48h416c26.5 0 48-21.5 48-48V80c0-26.5-21.5-48-48-48zm0 394c0 3.3-2.7 6-6 6H54c-3.3 0-6-2.7-6-6V192h416v234z" />
              </svg>
            ) : (
              <svg
                className="windows"
                onClick={windowsHandler}
                xmlns="http://www.w3.org/2000/svg"
                height="20"
                width="20"
                viewBox="0 0 512 512"
              >
                <path d="M464 352H48c-26.5 0-48 21.5-48 48v32c0 26.5 21.5 48 48 48h416c26.5 0 48-21.5 48-48v-32c0-26.5-21.5-48-48-48z" />
              </svg>
            )}
          </div>
          <svg
            className="symbol"
            xmlns="http://www.w3.org/2000/svg"
            height="25"
            width="25"
            viewBox="0 0 384 512"
          >
            <path d="M64 464c-8.8 0-16-7.2-16-16V64c0-8.8 7.2-16 16-16H224v80c0 17.7 14.3 32 32 32h80V448c0 8.8-7.2 16-16 16H64zM64 0C28.7 0 0 28.7 0 64V448c0 35.3 28.7 64 64 64H320c35.3 0 64-28.7 64-64V154.5c0-17-6.7-33.3-18.7-45.3L274.7 18.7C262.7 6.7 246.5 0 229.5 0H64zm56 256c-13.3 0-24 10.7-24 24s10.7 24 24 24H264c13.3 0 24-10.7 24-24s-10.7-24-24-24H120zm0 96c-13.3 0-24 10.7-24 24s10.7 24 24 24H264c13.3 0 24-10.7 24-24s-10.7-24-24-24H120z" />
          </svg>
          <i className="toolbar_i">
            {" "}
            This is the preview of your markdown code:{" "}
          </i>
        </div>
        <div id="previ">
          <ReactMarkdown
            value={props.text_pass}
            remarkPlugins={[remarkGfm]}
            // rehypePlugins={[rehypeKatex]}
          >
            {preview_value}
          </ReactMarkdown>
        </div>
      </div>
    </div>
  );
}
