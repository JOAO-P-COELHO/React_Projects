import React,{useState} from "react";


function App() {

const[color, setColor] = useState(false)
function mouseOver(){
  setColor(true)
}

function mouseOut(){
  setColor(false)
}

  return (
    <div className="container">
      <h1>Oi</h1>
      <input type="text" placeholder="What's your name?" />
      <button onMouseOut={mouseOut} onMouseOver={mouseOver} style={{backgroundColor: color? "black" : "white"}} >Submit</button>
    </div>
  );
}

export default App;
