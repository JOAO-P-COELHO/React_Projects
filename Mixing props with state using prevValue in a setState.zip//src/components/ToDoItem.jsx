import React, {useState} from "react";

function ToDoItem(props){

  const [line, setLine] = useState(false)

function lineHandler(){
  setLine(prevValue => {
    return !prevValue;
  });
}
// It's called a function in setLine that uses the previous value (in the object property "line") as argument 
// and return it's opposite

    return(<li style={{textDecoration: line? "line-through" : "none"}} onClick={lineHandler} >{props.text}</li>)
};

export default ToDoItem;